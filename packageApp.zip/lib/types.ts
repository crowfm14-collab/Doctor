export type ProviderType = 'doctor' | 'hospital' | 'pharmacy' | 'laboratory'
export type ProviderStatus = 'pending' | 'verified' | 'rejected' | 'suspended'
export type WorkplaceType = 'hospital' | 'clinic' | 'private_cabinet' | 'other'
export type AppointmentStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed'

export interface Provider {
  id: string
  user_id: string | null
  provider_type: ProviderType
  full_name: string
  date_of_birth: string | null
  national_id: string | null
  phone: string
  email: string
  license_number: string
  specialty: string | null
  years_of_experience: number | null
  workplace: string | null
  workplace_type: WorkplaceType | null
  wilaya: string
  address: string
  latitude: number | null
  longitude: number | null
  diploma_url: string | null
  license_doc_url: string | null
  national_id_doc_url: string | null
  work_certificate_url: string | null
  status: ProviderStatus
  rejection_reason: string | null
  verified_at: string | null
  verified_by: string | null
  average_rating: number
  total_ratings: number
  created_at: string
  updated_at: string
}

export interface Appointment {
  id: string
  provider_id: string
  patient_name: string
  patient_phone: string
  patient_email: string | null
  appointment_date: string
  appointment_time: string
  status: AppointmentStatus
  notes: string | null
  created_at: string
  updated_at: string
  provider?: Provider
}

export interface AvailabilitySlot {
  id: string
  provider_id: string
  day_of_week: number
  start_time: string
  end_time: string
  is_available: boolean
  created_at: string
}

export interface Review {
  id: string
  provider_id: string
  reviewer_name: string
  rating: number
  comment: string | null
  created_at: string
}

export interface AdminUser {
  id: string
  user_id: string
  role: 'admin' | 'super_admin'
  created_at: string
}

export interface RegistrationFormData {
  // Personal Info
  full_name: string
  date_of_birth: string
  national_id: string
  phone: string
  email: string
  password: string
  
  // Professional Info
  provider_type: ProviderType
  license_number: string
  specialty: string
  years_of_experience: number
  workplace: string
  workplace_type: WorkplaceType
  
  // Location
  wilaya: string
  address: string
  latitude: number | null
  longitude: number | null
  
  // Documents
  diploma: File | null
  license_doc: File | null
  national_id_doc: File | null
  work_certificate: File | null
}
