export type Locale = 'en' | 'fr' | 'ar'

export const translations = {
  en: {
    // Navigation
    home: 'Home',
    findDoctors: 'Find Doctors',
    forProviders: 'For Providers',
    admin: 'Admin',
    login: 'Login',
    register: 'Register',
    
    // Hero
    heroTitle: 'Your Health, Our Priority',
    heroSubtitle: 'Find and book appointments with verified healthcare providers across Algeria',
    searchPlaceholder: 'Search doctors, specialties, or locations...',
    searchButton: 'Search',
    
    // Features
    verifiedDoctors: 'Verified Doctors',
    verifiedDoctorsDesc: 'All healthcare providers are verified by Algerian authorities',
    easyBooking: 'Easy Booking',
    easyBookingDesc: 'Book appointments online with just a few clicks',
    interactiveMap: 'Interactive Map',
    interactiveMapDesc: 'Find providers near you with our smart map',
    
    // Registration
    providerRegistration: 'Provider Registration',
    registerAsProvider: 'Register as Healthcare Provider',
    personalInfo: 'Personal Information',
    professionalInfo: 'Professional Information',
    locationInfo: 'Location',
    documents: 'Documents',
    
    // Form fields
    fullName: 'Full Name',
    dateOfBirth: 'Date of Birth',
    nationalId: 'National ID (Carte Nationale)',
    phone: 'Phone Number',
    email: 'Email',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    licenseNumber: 'Medical License Number',
    specialty: 'Specialty',
    yearsExperience: 'Years of Experience',
    workplace: 'Workplace Name',
    workplaceType: 'Workplace Type',
    wilaya: 'Wilaya',
    address: 'Address',
    
    // Documents
    diploma: 'Medical Diploma',
    licenseDoc: 'License Document',
    nationalIdDoc: 'National ID Document',
    workCertificate: 'Work Certificate (Optional)',
    uploadFile: 'Upload File',
    
    // Status
    pending: 'Pending',
    verified: 'Verified',
    rejected: 'Rejected',
    suspended: 'Suspended',
    
    // Actions
    submit: 'Submit',
    next: 'Next',
    previous: 'Previous',
    cancel: 'Cancel',
    save: 'Save',
    approve: 'Approve',
    reject: 'Reject',
    bookAppointment: 'Book Appointment',
    
    // Map
    nearMe: 'Near Me',
    filterBy: 'Filter by',
    allSpecialties: 'All Specialties',
    allWilayas: 'All Wilayas',
    
    // Doctor Profile
    experience: 'Experience',
    years: 'years',
    rating: 'Rating',
    reviews: 'Reviews',
    availability: 'Availability',
    selectDate: 'Select Date',
    selectTime: 'Select Time',
    
    // Booking
    yourName: 'Your Name',
    yourPhone: 'Your Phone',
    yourEmail: 'Your Email',
    notes: 'Notes (Optional)',
    confirmBooking: 'Confirm Booking',
    bookingSuccess: 'Appointment booked successfully!',
    
    // Admin
    dashboard: 'Dashboard',
    pendingReview: 'Pending Review',
    allProviders: 'All Providers',
    statistics: 'Statistics',
    viewDetails: 'View Details',
    approveProvider: 'Approve Provider',
    rejectProvider: 'Reject Provider',
    rejectionReason: 'Rejection Reason',
  },
  fr: {
    // Navigation
    home: 'Accueil',
    findDoctors: 'Trouver des Médecins',
    forProviders: 'Pour les Prestataires',
    admin: 'Admin',
    login: 'Connexion',
    register: "S'inscrire",
    
    // Hero
    heroTitle: 'Votre Santé, Notre Priorité',
    heroSubtitle: 'Trouvez et prenez rendez-vous avec des prestataires de santé vérifiés à travers l\'Algérie',
    searchPlaceholder: 'Rechercher des médecins, spécialités ou lieux...',
    searchButton: 'Rechercher',
    
    // Features
    verifiedDoctors: 'Médecins Vérifiés',
    verifiedDoctorsDesc: 'Tous les prestataires de santé sont vérifiés par les autorités algériennes',
    easyBooking: 'Réservation Facile',
    easyBookingDesc: 'Prenez rendez-vous en ligne en quelques clics',
    interactiveMap: 'Carte Interactive',
    interactiveMapDesc: 'Trouvez des prestataires près de chez vous avec notre carte intelligente',
    
    // Registration
    providerRegistration: 'Inscription Prestataire',
    registerAsProvider: 'S\'inscrire comme Prestataire de Santé',
    personalInfo: 'Informations Personnelles',
    professionalInfo: 'Informations Professionnelles',
    locationInfo: 'Localisation',
    documents: 'Documents',
    
    // Form fields
    fullName: 'Nom Complet',
    dateOfBirth: 'Date de Naissance',
    nationalId: 'Carte Nationale d\'Identité',
    phone: 'Numéro de Téléphone',
    email: 'Email',
    password: 'Mot de Passe',
    confirmPassword: 'Confirmer le Mot de Passe',
    licenseNumber: 'Numéro de Licence Médicale',
    specialty: 'Spécialité',
    yearsExperience: 'Années d\'Expérience',
    workplace: 'Nom du Lieu de Travail',
    workplaceType: 'Type de Lieu de Travail',
    wilaya: 'Wilaya',
    address: 'Adresse',
    
    // Documents
    diploma: 'Diplôme Médical',
    licenseDoc: 'Document de Licence',
    nationalIdDoc: 'Document d\'Identité Nationale',
    workCertificate: 'Certificat de Travail (Optionnel)',
    uploadFile: 'Télécharger le Fichier',
    
    // Status
    pending: 'En Attente',
    verified: 'Vérifié',
    rejected: 'Rejeté',
    suspended: 'Suspendu',
    
    // Actions
    submit: 'Soumettre',
    next: 'Suivant',
    previous: 'Précédent',
    cancel: 'Annuler',
    save: 'Enregistrer',
    approve: 'Approuver',
    reject: 'Rejeter',
    bookAppointment: 'Prendre Rendez-vous',
    
    // Map
    nearMe: 'Près de Moi',
    filterBy: 'Filtrer par',
    allSpecialties: 'Toutes les Spécialités',
    allWilayas: 'Toutes les Wilayas',
    
    // Doctor Profile
    experience: 'Expérience',
    years: 'ans',
    rating: 'Note',
    reviews: 'Avis',
    availability: 'Disponibilité',
    selectDate: 'Sélectionner une Date',
    selectTime: 'Sélectionner une Heure',
    
    // Booking
    yourName: 'Votre Nom',
    yourPhone: 'Votre Téléphone',
    yourEmail: 'Votre Email',
    notes: 'Notes (Optionnel)',
    confirmBooking: 'Confirmer la Réservation',
    bookingSuccess: 'Rendez-vous réservé avec succès!',
    
    // Admin
    dashboard: 'Tableau de Bord',
    pendingReview: 'En Attente de Révision',
    allProviders: 'Tous les Prestataires',
    statistics: 'Statistiques',
    viewDetails: 'Voir les Détails',
    approveProvider: 'Approuver le Prestataire',
    rejectProvider: 'Rejeter le Prestataire',
    rejectionReason: 'Raison du Rejet',
  },
  ar: {
    // Navigation
    home: 'الرئيسية',
    findDoctors: 'ابحث عن أطباء',
    forProviders: 'للمقدمين',
    admin: 'الإدارة',
    login: 'تسجيل الدخول',
    register: 'التسجيل',
    
    // Hero
    heroTitle: 'صحتك، أولويتنا',
    heroSubtitle: 'ابحث واحجز مواعيد مع مقدمي الرعاية الصحية المعتمدين في جميع أنحاء الجزائر',
    searchPlaceholder: 'ابحث عن الأطباء، التخصصات أو المواقع...',
    searchButton: 'بحث',
    
    // Features
    verifiedDoctors: 'أطباء معتمدون',
    verifiedDoctorsDesc: 'جميع مقدمي الرعاية الصحية معتمدون من قبل السلطات الجزائرية',
    easyBooking: 'حجز سهل',
    easyBookingDesc: 'احجز المواعيد عبر الإنترنت بنقرات قليلة',
    interactiveMap: 'خريطة تفاعلية',
    interactiveMapDesc: 'اعثر على مقدمي الخدمة بالقرب منك مع خريطتنا الذكية',
    
    // Registration
    providerRegistration: 'تسجيل المقدم',
    registerAsProvider: 'سجل كمقدم رعاية صحية',
    personalInfo: 'المعلومات الشخصية',
    professionalInfo: 'المعلومات المهنية',
    locationInfo: 'الموقع',
    documents: 'الوثائق',
    
    // Form fields
    fullName: 'الاسم الكامل',
    dateOfBirth: 'تاريخ الميلاد',
    nationalId: 'رقم البطاقة الوطنية',
    phone: 'رقم الهاتف',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    confirmPassword: 'تأكيد كلمة المرور',
    licenseNumber: 'رقم رخصة الطب',
    specialty: 'التخصص',
    yearsExperience: 'سنوات الخبرة',
    workplace: 'اسم مكان العمل',
    workplaceType: 'نوع مكان العمل',
    wilaya: 'الولاية',
    address: 'العنوان',
    
    // Documents
    diploma: 'شهادة الطب',
    licenseDoc: 'وثيقة الرخصة',
    nationalIdDoc: 'وثيقة البطاقة الوطنية',
    workCertificate: 'شهادة العمل (اختياري)',
    uploadFile: 'رفع الملف',
    
    // Status
    pending: 'قيد الانتظار',
    verified: 'معتمد',
    rejected: 'مرفوض',
    suspended: 'معلق',
    
    // Actions
    submit: 'إرسال',
    next: 'التالي',
    previous: 'السابق',
    cancel: 'إلغاء',
    save: 'حفظ',
    approve: 'موافقة',
    reject: 'رفض',
    bookAppointment: 'حجز موعد',
    
    // Map
    nearMe: 'بالقرب مني',
    filterBy: 'تصفية حسب',
    allSpecialties: 'جميع التخصصات',
    allWilayas: 'جميع الولايات',
    
    // Doctor Profile
    experience: 'الخبرة',
    years: 'سنوات',
    rating: 'التقييم',
    reviews: 'المراجعات',
    availability: 'التوفر',
    selectDate: 'اختر التاريخ',
    selectTime: 'اختر الوقت',
    
    // Booking
    yourName: 'اسمك',
    yourPhone: 'هاتفك',
    yourEmail: 'بريدك الإلكتروني',
    notes: 'ملاحظات (اختياري)',
    confirmBooking: 'تأكيد الحجز',
    bookingSuccess: 'تم حجز الموعد بنجاح!',
    
    // Admin
    dashboard: 'لوحة التحكم',
    pendingReview: 'قيد المراجعة',
    allProviders: 'جميع المقدمين',
    statistics: 'الإحصائيات',
    viewDetails: 'عرض التفاصيل',
    approveProvider: 'موافقة على المقدم',
    rejectProvider: 'رفض المقدم',
    rejectionReason: 'سبب الرفض',
  },
} as const

export function useTranslation(locale: Locale) {
  return translations[locale]
}

export function getDirection(locale: Locale): 'ltr' | 'rtl' {
  return locale === 'ar' ? 'rtl' : 'ltr'
}
