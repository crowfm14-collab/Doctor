import { 
  Stethoscope, 
  Heart, 
  Sparkles, 
  Baby, 
  Users, 
  Brain, 
  Bone, 
  Eye, 
  SmilePlus, 
  HeartPulse, 
  Scan, 
  Syringe, 
  Activity, 
  Pill, 
  Ear, 
  Droplets, 
  Microscope, 
  Wind,
  Building2,
  FlaskConical,
  Hospital
} from 'lucide-react'

export const SPECIALTIES = [
  { value: 'general_medicine', label: 'General Medicine', labelAr: 'الطب العام', labelFr: 'Médecine Générale', icon: Stethoscope },
  { value: 'cardiology', label: 'Cardiology', labelAr: 'أمراض القلب', labelFr: 'Cardiologie', icon: Heart },
  { value: 'dermatology', label: 'Dermatology', labelAr: 'الأمراض الجلدية', labelFr: 'Dermatologie', icon: Sparkles },
  { value: 'pediatrics', label: 'Pediatrics', labelAr: 'طب الأطفال', labelFr: 'Pédiatrie', icon: Baby },
  { value: 'gynecology', label: 'Gynecology', labelAr: 'أمراض النساء', labelFr: 'Gynécologie', icon: Users },
  { value: 'neurology', label: 'Neurology', labelAr: 'طب الأعصاب', labelFr: 'Neurologie', icon: Brain },
  { value: 'orthopedics', label: 'Orthopedics', labelAr: 'جراحة العظام', labelFr: 'Orthopédie', icon: Bone },
  { value: 'ophthalmology', label: 'Ophthalmology', labelAr: 'طب العيون', labelFr: 'Ophtalmologie', icon: Eye },
  { value: 'dentistry', label: 'Dentistry', labelAr: 'طب الأسنان', labelFr: 'Dentisterie', icon: SmilePlus },
  { value: 'psychiatry', label: 'Psychiatry', labelAr: 'الطب النفسي', labelFr: 'Psychiatrie', icon: HeartPulse },
  { value: 'radiology', label: 'Radiology', labelAr: 'الأشعة', labelFr: 'Radiologie', icon: Scan },
  { value: 'anesthesiology', label: 'Anesthesiology', labelAr: 'التخدير', labelFr: 'Anesthésiologie', icon: Syringe },
  { value: 'urology', label: 'Urology', labelAr: 'المسالك البولية', labelFr: 'Urologie', icon: Activity },
  { value: 'oncology', label: 'Oncology', labelAr: 'علاج الأورام', labelFr: 'Oncologie', icon: Pill },
  { value: 'ent', label: 'ENT (Oto-rhino-laryngology)', labelAr: 'أنف وأذن وحنجرة', labelFr: 'ORL', icon: Ear },
  { value: 'endocrinology', label: 'Endocrinology', labelAr: 'الغدد الصماء', labelFr: 'Endocrinologie', icon: Droplets },
  { value: 'gastroenterology', label: 'Gastroenterology', labelAr: 'أمراض الجهاز الهضمي', labelFr: 'Gastroentérologie', icon: Microscope },
  { value: 'nephrology', label: 'Nephrology', labelAr: 'أمراض الكلى', labelFr: 'Néphrologie', icon: Droplets },
  { value: 'pulmonology', label: 'Pulmonology', labelAr: 'أمراض الرئة', labelFr: 'Pneumologie', icon: Wind },
] as const

export const WILAYAS = [
  { code: '01', name: 'Adrar', nameAr: 'أدرار' },
  { code: '02', name: 'Chlef', nameAr: 'الشلف' },
  { code: '03', name: 'Laghouat', nameAr: 'الأغواط' },
  { code: '04', name: 'Oum El Bouaghi', nameAr: 'أم البواقي' },
  { code: '05', name: 'Batna', nameAr: 'باتنة' },
  { code: '06', name: 'Béjaïa', nameAr: 'بجاية' },
  { code: '07', name: 'Biskra', nameAr: 'بسكرة' },
  { code: '08', name: 'Béchar', nameAr: 'بشار' },
  { code: '09', name: 'Blida', nameAr: 'البليدة' },
  { code: '10', name: 'Bouira', nameAr: 'البويرة' },
  { code: '11', name: 'Tamanrasset', nameAr: 'تمنراست' },
  { code: '12', name: 'Tébessa', nameAr: 'تبسة' },
  { code: '13', name: 'Tlemcen', nameAr: 'تلمسان' },
  { code: '14', name: 'Tiaret', nameAr: 'تيارت' },
  { code: '15', name: 'Tizi Ouzou', nameAr: 'تيزي وزو' },
  { code: '16', name: 'Algiers', nameAr: 'الجزائر' },
  { code: '17', name: 'Djelfa', nameAr: 'الجلفة' },
  { code: '18', name: 'Jijel', nameAr: 'جيجل' },
  { code: '19', name: 'Sétif', nameAr: 'سطيف' },
  { code: '20', name: 'Saïda', nameAr: 'سعيدة' },
  { code: '21', name: 'Skikda', nameAr: 'سكيكدة' },
  { code: '22', name: 'Sidi Bel Abbès', nameAr: 'سيدي بلعباس' },
  { code: '23', name: 'Annaba', nameAr: 'عنابة' },
  { code: '24', name: 'Guelma', nameAr: 'قالمة' },
  { code: '25', name: 'Constantine', nameAr: 'قسنطينة' },
  { code: '26', name: 'Médéa', nameAr: 'المدية' },
  { code: '27', name: 'Mostaganem', nameAr: 'مستغانم' },
  { code: '28', name: "M'Sila", nameAr: 'المسيلة' },
  { code: '29', name: 'Mascara', nameAr: 'معسكر' },
  { code: '30', name: 'Ouargla', nameAr: 'ورقلة' },
  { code: '31', name: 'Oran', nameAr: 'وهران' },
  { code: '32', name: 'El Bayadh', nameAr: 'البيض' },
  { code: '33', name: 'Illizi', nameAr: 'إليزي' },
  { code: '34', name: 'Bordj Bou Arréridj', nameAr: 'برج بوعريريج' },
  { code: '35', name: 'Boumerdès', nameAr: 'بومرداس' },
  { code: '36', name: 'El Tarf', nameAr: 'الطارف' },
  { code: '37', name: 'Tindouf', nameAr: 'تندوف' },
  { code: '38', name: 'Tissemsilt', nameAr: 'تيسمسيلت' },
  { code: '39', name: 'El Oued', nameAr: 'الوادي' },
  { code: '40', name: 'Khenchela', nameAr: 'خنشلة' },
  { code: '41', name: 'Souk Ahras', nameAr: 'سوق أهراس' },
  { code: '42', name: 'Tipaza', nameAr: 'تيبازة' },
  { code: '43', name: 'Mila', nameAr: 'ميلة' },
  { code: '44', name: 'Aïn Defla', nameAr: 'عين الدفلى' },
  { code: '45', name: 'Naâma', nameAr: 'النعامة' },
  { code: '46', name: 'Aïn Témouchent', nameAr: 'عين تموشنت' },
  { code: '47', name: 'Ghardaïa', nameAr: 'غرداية' },
  { code: '48', name: 'Relizane', nameAr: 'غليزان' },
  { code: '49', name: 'Timimoun', nameAr: 'تيميمون' },
  { code: '50', name: 'Bordj Badji Mokhtar', nameAr: 'برج باجي مختار' },
  { code: '51', name: 'Ouled Djellal', nameAr: 'أولاد جلال' },
  { code: '52', name: 'Béni Abbès', nameAr: 'بني عباس' },
  { code: '53', name: 'In Salah', nameAr: 'عين صالح' },
  { code: '54', name: 'In Guezzam', nameAr: 'عين قزام' },
  { code: '55', name: 'Touggourt', nameAr: 'تقرت' },
  { code: '56', name: 'Djanet', nameAr: 'جانت' },
  { code: '57', name: 'El Meghaïer', nameAr: 'المغير' },
  { code: '58', name: 'El Meniaa', nameAr: 'المنيعة' },
] as const

export const PROVIDER_TYPES = [
  { value: 'doctor', label: 'Doctor', labelAr: 'طبيب', labelFr: 'Médecin', icon: Stethoscope },
  { value: 'hospital', label: 'Hospital', labelAr: 'مستشفى', labelFr: 'Hôpital', icon: Hospital },
  { value: 'pharmacy', label: 'Pharmacy', labelAr: 'صيدلية', labelFr: 'Pharmacie', icon: Pill },
  { value: 'laboratory', label: 'Laboratory', labelAr: 'مختبر', labelFr: 'Laboratoire', icon: FlaskConical },
] as const

export const WORKPLACE_TYPES = [
  { value: 'hospital', label: 'Hospital', labelAr: 'مستشفى', labelFr: 'Hôpital' },
  { value: 'clinic', label: 'Clinic', labelAr: 'عيادة', labelFr: 'Clinique' },
  { value: 'private_cabinet', label: 'Private Cabinet', labelAr: 'عيادة خاصة', labelFr: 'Cabinet Privé' },
  { value: 'other', label: 'Other', labelAr: 'أخرى', labelFr: 'Autre' },
] as const

export const STATUS_COLORS = {
  pending: { bg: 'bg-warning/10', text: 'text-warning', border: 'border-warning/30' },
  verified: { bg: 'bg-success/10', text: 'text-success', border: 'border-success/30' },
  rejected: { bg: 'bg-destructive/10', text: 'text-destructive', border: 'border-destructive/30' },
  suspended: { bg: 'bg-muted', text: 'text-muted-foreground', border: 'border-muted' },
} as const

// Algeria center coordinates
export const ALGERIA_CENTER = {
  lat: 28.0339,
  lng: 1.6596,
  zoom: 5,
}

// Major cities coordinates for demo
export const CITY_COORDINATES: Record<string, { lat: number; lng: number }> = {
  '16': { lat: 36.7538, lng: 3.0588 }, // Algiers
  '31': { lat: 35.6969, lng: -0.6331 }, // Oran
  '25': { lat: 36.3650, lng: 6.6147 }, // Constantine
  '23': { lat: 36.9000, lng: 7.7667 }, // Annaba
  '09': { lat: 36.4722, lng: 2.8281 }, // Blida
  '19': { lat: 36.1898, lng: 5.4108 }, // Sétif
  '06': { lat: 36.7500, lng: 5.0667 }, // Béjaïa
  '05': { lat: 35.5556, lng: 6.1744 }, // Batna
}

export const DAYS_OF_WEEK = [
  { value: 0, label: 'Sunday', labelAr: 'الأحد', labelFr: 'Dimanche' },
  { value: 1, label: 'Monday', labelAr: 'الاثنين', labelFr: 'Lundi' },
  { value: 2, label: 'Tuesday', labelAr: 'الثلاثاء', labelFr: 'Mardi' },
  { value: 3, label: 'Wednesday', labelAr: 'الأربعاء', labelFr: 'Mercredi' },
  { value: 4, label: 'Thursday', labelAr: 'الخميس', labelFr: 'Jeudi' },
  { value: 5, label: 'Friday', labelAr: 'الجمعة', labelFr: 'Vendredi' },
  { value: 6, label: 'Saturday', labelAr: 'السبت', labelFr: 'Samedi' },
] as const
