'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Star, MapPin, Clock, Phone, BadgeCheck, Calendar } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SPECIALTIES, WILAYAS } from '@/lib/constants'
import { type Provider } from '@/lib/types'

interface ProviderCardProps {
  provider: Provider
  isSelected?: boolean
  onSelect?: (provider: Provider) => void
  variant?: 'default' | 'compact'
}

export function ProviderCard({ 
  provider, 
  isSelected = false, 
  onSelect,
  variant = 'default'
}: ProviderCardProps) {
  const specialty = SPECIALTIES.find(s => s.value === provider.specialty)
  const wilaya = WILAYAS.find(w => w.code === provider.wilaya)
  const SpecialtyIcon = specialty?.icon

  if (variant === 'compact') {
    return (
      <motion.div
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => onSelect?.(provider)}
        className={`p-4 rounded-xl border cursor-pointer transition-all ${
          isSelected 
            ? 'border-primary bg-primary/5 shadow-md' 
            : 'bg-card hover:border-primary/30 hover:shadow-sm'
        }`}
      >
        <div className="flex items-start gap-3">
          <div className={`flex h-12 w-12 items-center justify-center rounded-xl shrink-0 ${
            isSelected ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary'
          }`}>
            {SpecialtyIcon && <SpecialtyIcon className="h-6 w-6" />}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="font-semibold truncate">{provider.full_name}</h3>
              {provider.status === 'verified' && (
                <BadgeCheck className="h-4 w-4 text-primary fill-primary/20 shrink-0" />
              )}
            </div>
            
            {specialty && (
              <p className="text-sm text-muted-foreground">{specialty.label}</p>
            )}
            
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              {provider.average_rating > 0 && (
                <span className="flex items-center gap-1">
                  <Star className="h-3 w-3 fill-warning text-warning" />
                  {provider.average_rating.toFixed(1)}
                </span>
              )}
              {wilaya && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {wilaya.name}
                </span>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className={`group relative overflow-hidden rounded-2xl border bg-card transition-all hover:shadow-lg ${
        isSelected ? 'border-primary shadow-lg' : 'hover:border-primary/30'
      }`}
    >
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="relative p-6">
        <div className="flex items-start gap-4">
          {/* Avatar/Icon */}
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
            {SpecialtyIcon && <SpecialtyIcon className="h-8 w-8" />}
          </div>
          
          <div className="flex-1 min-w-0">
            {/* Header */}
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-semibold text-lg">{provider.full_name}</h3>
                  {provider.status === 'verified' && (
                    <BadgeCheck className="h-5 w-5 text-primary fill-primary/20" />
                  )}
                </div>
                {specialty && (
                  <p className="text-sm text-muted-foreground">{specialty.label}</p>
                )}
              </div>
              
              {provider.average_rating > 0 && (
                <div className="flex items-center gap-1 bg-warning/10 px-2.5 py-1 rounded-full">
                  <Star className="h-4 w-4 fill-warning text-warning" />
                  <span className="text-sm font-semibold">{provider.average_rating.toFixed(1)}</span>
                  <span className="text-xs text-muted-foreground">({provider.total_ratings})</span>
                </div>
              )}
            </div>
            
            {/* Details */}
            <div className="mt-4 grid gap-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 shrink-0" />
                <span className="truncate">{provider.address}</span>
              </div>
              
              {provider.years_of_experience && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 shrink-0" />
                  <span>{provider.years_of_experience} years of experience</span>
                </div>
              )}
              
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 shrink-0" />
                <span>{provider.phone}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Actions */}
        <div className="mt-6 flex gap-3">
          <Link href={`/doctor/${provider.id}`} className="flex-1">
            <Button variant="outline" className="w-full group-hover:border-primary/30">
              View Profile
            </Button>
          </Link>
          <Link href={`/doctor/${provider.id}?book=true`} className="flex-1">
            <Button className="w-full gap-2">
              <Calendar className="h-4 w-4" />
              Book
            </Button>
          </Link>
        </div>
      </div>
    </motion.div>
  )
}
