'use client'

import { useEffect, useState, useMemo } from 'react'
import dynamic from 'next/dynamic'
import { motion } from 'framer-motion'
import { Loader2, Star, MapPin, Phone, Clock, BadgeCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ALGERIA_CENTER, SPECIALTIES } from '@/lib/constants'
import { type Provider } from '@/lib/types'
import Link from 'next/link'

// Dynamic imports for Leaflet components
const MapContainer = dynamic(
  () => import('react-leaflet').then((mod) => mod.MapContainer),
  { ssr: false, loading: () => <MapSkeleton /> }
)

const TileLayer = dynamic(
  () => import('react-leaflet').then((mod) => mod.TileLayer),
  { ssr: false }
)

const Marker = dynamic(
  () => import('react-leaflet').then((mod) => mod.Marker),
  { ssr: false }
)

const Popup = dynamic(
  () => import('react-leaflet').then((mod) => mod.Popup),
  { ssr: false }
)

function MapSkeleton() {
  return (
    <div className="h-full w-full bg-muted rounded-xl flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
    </div>
  )
}

interface ProvidersMapProps {
  providers: Provider[]
  selectedProvider?: Provider | null
  onProviderSelect?: (provider: Provider) => void
  className?: string
}

export function ProvidersMap({ 
  providers, 
  selectedProvider, 
  onProviderSelect,
  className = ''
}: ProvidersMapProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [customIcon, setCustomIcon] = useState<any>(null)
  const [selectedIcon, setSelectedIcon] = useState<any>(null)

  useEffect(() => {
    setIsMounted(true)
    
    // Create custom icons
    import('leaflet').then((L) => {
      const defaultIcon = L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 14px rgba(59, 130, 246, 0.4);
            color: white;
            border: 3px solid white;
          ">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/>
              <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4"/>
              <circle cx="20" cy="10" r="2"/>
            </svg>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 36],
        popupAnchor: [0, -36],
      })

      const highlightIcon = L.divIcon({
        className: 'custom-marker-selected',
        html: `
          <div style="
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, #10b981, #059669);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 20px rgba(16, 185, 129, 0.5);
            color: white;
            border: 3px solid white;
            animation: pulse 2s infinite;
          ">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/>
              <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4"/>
              <circle cx="20" cy="10" r="2"/>
            </svg>
          </div>
        `,
        iconSize: [44, 44],
        iconAnchor: [22, 44],
        popupAnchor: [0, -44],
      })

      setCustomIcon(defaultIcon)
      setSelectedIcon(highlightIcon)
    })
  }, [])

  // Calculate map bounds based on providers
  const mapCenter = useMemo(() => {
    if (selectedProvider?.latitude && selectedProvider?.longitude) {
      return [selectedProvider.latitude, selectedProvider.longitude] as [number, number]
    }
    
    if (providers.length > 0) {
      const validProviders = providers.filter(p => p.latitude && p.longitude)
      if (validProviders.length > 0) {
        const avgLat = validProviders.reduce((sum, p) => sum + (p.latitude || 0), 0) / validProviders.length
        const avgLng = validProviders.reduce((sum, p) => sum + (p.longitude || 0), 0) / validProviders.length
        return [avgLat, avgLng] as [number, number]
      }
    }
    
    return [ALGERIA_CENTER.lat, ALGERIA_CENTER.lng] as [number, number]
  }, [providers, selectedProvider])

  if (!isMounted) {
    return <MapSkeleton />
  }

  return (
    <div className={`h-full w-full rounded-xl overflow-hidden ${className}`}>
      <MapContainer
        center={mapCenter}
        zoom={selectedProvider ? 14 : 6}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {providers.map((provider) => {
          if (!provider.latitude || !provider.longitude || !customIcon) return null
          
          const isSelected = selectedProvider?.id === provider.id
          const specialty = SPECIALTIES.find(s => s.value === provider.specialty)
          
          return (
            <Marker
              key={provider.id}
              position={[provider.latitude, provider.longitude]}
              icon={isSelected && selectedIcon ? selectedIcon : customIcon}
              eventHandlers={{
                click: () => onProviderSelect?.(provider),
              }}
            >
              <Popup>
                <ProviderPopup provider={provider} />
              </Popup>
            </Marker>
          )
        })}
      </MapContainer>
    </div>
  )
}

function ProviderPopup({ provider }: { provider: Provider }) {
  const specialty = SPECIALTIES.find(s => s.value === provider.specialty)
  const SpecialtyIcon = specialty?.icon

  return (
    <div className="w-64 p-0">
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-semibold text-foreground">{provider.full_name}</h3>
              {provider.status === 'verified' && (
                <BadgeCheck className="h-4 w-4 text-primary fill-primary/20" />
              )}
            </div>
            {specialty && (
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-0.5">
                {SpecialtyIcon && <SpecialtyIcon className="h-3 w-3" />}
                {specialty.label}
              </p>
            )}
          </div>
          {provider.average_rating > 0 && (
            <div className="flex items-center gap-1 bg-warning/10 px-2 py-0.5 rounded-full">
              <Star className="h-3 w-3 fill-warning text-warning" />
              <span className="text-xs font-medium">{provider.average_rating.toFixed(1)}</span>
            </div>
          )}
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            <span className="truncate">{provider.address}</span>
          </div>
          {provider.years_of_experience && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>{provider.years_of_experience} years experience</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-muted-foreground">
            <Phone className="h-3.5 w-3.5" />
            <span>{provider.phone}</span>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <Link href={`/doctor/${provider.id}`} className="flex-1">
            <Button size="sm" variant="outline" className="w-full text-xs">
              View Profile
            </Button>
          </Link>
          <Link href={`/doctor/${provider.id}?book=true`} className="flex-1">
            <Button size="sm" className="w-full text-xs">
              Book Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
