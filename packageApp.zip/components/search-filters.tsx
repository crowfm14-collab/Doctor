'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Filter, X, MapPin, Stethoscope, Building2, Pill, FlaskConical, SlidersHorizontal } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { SPECIALTIES, WILAYAS, PROVIDER_TYPES } from '@/lib/constants'
import { type ProviderType } from '@/lib/types'

export interface SearchFilters {
  query: string
  specialty: string
  wilaya: string
  providerType: ProviderType | ''
  nearMe: boolean
}

interface SearchFiltersProps {
  filters: SearchFilters
  onFiltersChange: (filters: SearchFilters) => void
  resultCount?: number
}

export function SearchFiltersComponent({ 
  filters, 
  onFiltersChange,
  resultCount = 0 
}: SearchFiltersProps) {
  const [showMoreFilters, setShowMoreFilters] = useState(false)

  const updateFilter = <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => {
    onFiltersChange({ ...filters, [key]: value })
  }

  const clearFilters = () => {
    onFiltersChange({
      query: '',
      specialty: '',
      wilaya: '',
      providerType: '',
      nearMe: false,
    })
  }

  const hasActiveFilters = filters.specialty || filters.wilaya || filters.providerType || filters.nearMe

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search doctors, specialties..."
            value={filters.query}
            onChange={(e) => updateFilter('query', e.target.value)}
            className="pl-12 h-12 text-base rounded-xl border-border bg-card"
          />
        </div>
        <Button
          variant={showMoreFilters ? 'default' : 'outline'}
          size="lg"
          onClick={() => setShowMoreFilters(!showMoreFilters)}
          className="h-12 px-4 rounded-xl gap-2"
        >
          <SlidersHorizontal className="h-5 w-5" />
          <span className="hidden sm:inline">Filters</span>
          {hasActiveFilters && (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">
              {[filters.specialty, filters.wilaya, filters.providerType, filters.nearMe].filter(Boolean).length}
            </span>
          )}
        </Button>
      </div>

      {/* Provider Type Quick Filters */}
      <div className="flex flex-wrap gap-2">
        {PROVIDER_TYPES.map((type) => {
          const isActive = filters.providerType === type.value
          return (
            <motion.button
              key={type.value}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => updateFilter('providerType', isActive ? '' : type.value as ProviderType)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'bg-card border hover:border-primary/30 hover:bg-accent'
              }`}
            >
              <type.icon className="h-4 w-4" />
              {type.label}
            </motion.button>
          )
        })}
        
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => updateFilter('nearMe', !filters.nearMe)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
            filters.nearMe
              ? 'bg-success text-success-foreground shadow-sm'
              : 'bg-card border hover:border-success/30 hover:bg-success/10'
          }`}
        >
          <MapPin className="h-4 w-4" />
          Near Me
        </motion.button>
      </div>

      {/* Extended Filters */}
      <AnimatePresence>
        {showMoreFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 rounded-xl bg-card border space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Specialty</label>
                  <select
                    value={filters.specialty}
                    onChange={(e) => updateFilter('specialty', e.target.value)}
                    className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="">All Specialties</option>
                    {SPECIALTIES.map((specialty) => (
                      <option key={specialty.value} value={specialty.value}>
                        {specialty.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Wilaya</label>
                  <select
                    value={filters.wilaya}
                    onChange={(e) => updateFilter('wilaya', e.target.value)}
                    className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="">All Wilayas</option>
                    {WILAYAS.map((wilaya) => (
                      <option key={wilaya.code} value={wilaya.code}>
                        {wilaya.code} - {wilaya.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {hasActiveFilters && (
                <div className="flex items-center justify-between pt-2 border-t">
                  <p className="text-sm text-muted-foreground">
                    {resultCount} result{resultCount !== 1 ? 's' : ''} found
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearFilters}
                    className="text-destructive hover:text-destructive gap-1"
                  >
                    <X className="h-4 w-4" />
                    Clear filters
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
