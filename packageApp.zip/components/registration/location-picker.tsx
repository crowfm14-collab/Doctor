'use client'

import { useEffect, useState, useCallback } from 'react'
import dynamic from 'next/dynamic'
import { MapPin, Crosshair, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ALGERIA_CENTER } from '@/lib/constants'

// Dynamic import to avoid SSR issues with Leaflet
const MapContainer = dynamic(
  () => import('react-leaflet').then((mod) => mod.MapContainer),
  { ssr: false }
)

const TileLayer = dynamic(
  () => import('react-leaflet').then((mod) => mod.TileLayer),
  { ssr: false }
)

const Marker = dynamic(
  () => import('react-leaflet').then((mod) => mod.Marker),
  { ssr: false }
)

const useMapEvents = dynamic(
  () => import('react-leaflet').then((mod) => mod.useMapEvents),
  { ssr: false }
) as any

interface LocationPickerProps {
  latitude: number | null
  longitude: number | null
  onLocationSelect: (lat: number, lng: number) => void
}

function MapClickHandler({ onLocationSelect }: { onLocationSelect: (lat: number, lng: number) => void }) {
  const [useMapEventsHook, setUseMapEventsHook] = useState<any>(null)

  useEffect(() => {
    import('react-leaflet').then((mod) => {
      setUseMapEventsHook(() => mod.useMapEvents)
    })
  }, [])

  if (!useMapEventsHook) return null

  return <MapClickHandlerInner onLocationSelect={onLocationSelect} useMapEvents={useMapEventsHook} />
}

function MapClickHandlerInner({ 
  onLocationSelect, 
  useMapEvents 
}: { 
  onLocationSelect: (lat: number, lng: number) => void
  useMapEvents: any
}) {
  useMapEvents({
    click: (e: any) => {
      onLocationSelect(e.latlng.lat, e.latlng.lng)
    },
  })
  return null
}

export function LocationPicker({ latitude, longitude, onLocationSelect }: LocationPickerProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [isLocating, setIsLocating] = useState(false)
  const [customIcon, setCustomIcon] = useState<any>(null)

  useEffect(() => {
    setIsMounted(true)
    
    // Create custom icon
    import('leaflet').then((L) => {
      const icon = L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 14px rgba(59, 130, 246, 0.4);
            color: white;
            position: relative;
          ">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
      })
      setCustomIcon(icon)
    })
  }, [])

  const handleGetCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser')
      return
    }

    setIsLocating(true)
    navigator.geolocation.getCurrentPosition(
      (position) => {
        onLocationSelect(position.coords.latitude, position.coords.longitude)
        setIsLocating(false)
      },
      (error) => {
        console.error('Error getting location:', error)
        setIsLocating(false)
        alert('Could not get your location. Please select manually on the map.')
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    )
  }, [onLocationSelect])

  if (!isMounted) {
    return (
      <div className="h-[300px] rounded-xl bg-muted animate-pulse flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  const center = latitude && longitude 
    ? [latitude, longitude] as [number, number]
    : [ALGERIA_CENTER.lat, ALGERIA_CENTER.lng] as [number, number]

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleGetCurrentLocation}
          disabled={isLocating}
          className="gap-2"
        >
          {isLocating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Crosshair className="h-4 w-4" />
          )}
          Use My Location
        </Button>
        <span className="text-xs text-muted-foreground">or click on the map</span>
      </div>

      <div className="h-[300px] rounded-xl overflow-hidden border">
        <MapContainer
          center={center}
          zoom={latitude && longitude ? 15 : ALGERIA_CENTER.zoom}
          scrollWheelZoom={true}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapClickHandler onLocationSelect={onLocationSelect} />
          {latitude && longitude && customIcon && (
            <Marker 
              position={[latitude, longitude]} 
              icon={customIcon}
            />
          )}
        </MapContainer>
      </div>

      {latitude && longitude && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" />
          <span>Location selected: {latitude.toFixed(6)}, {longitude.toFixed(6)}</span>
        </div>
      )}
    </div>
  )
}
