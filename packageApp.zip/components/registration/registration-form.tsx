'use client'

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  User, Briefcase, MapPin, FileText, Check, ChevronRight, ChevronLeft,
  Upload, X, Loader2, Eye, EyeOff
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { type Locale, translations, getDirection } from '@/lib/i18n'
import { SPECIALTIES, WILAYAS, PROVIDER_TYPES, WORKPLACE_TYPES } from '@/lib/constants'
import { type RegistrationFormData, type ProviderType, type WorkplaceType } from '@/lib/types'
import { LocationPicker } from './location-picker'
import { createClient } from '@/lib/supabase/client'

interface RegistrationFormProps {
  locale: Locale
}

const STEPS = [
  { id: 1, icon: User, key: 'personalInfo' },
  { id: 2, icon: Briefcase, key: 'professionalInfo' },
  { id: 3, icon: MapPin, key: 'locationInfo' },
  { id: 4, icon: FileText, key: 'documents' },
] as const

const initialFormData: RegistrationFormData = {
  full_name: '',
  date_of_birth: '',
  national_id: '',
  phone: '',
  email: '',
  password: '',
  provider_type: 'doctor',
  license_number: '',
  specialty: '',
  years_of_experience: 0,
  workplace: '',
  workplace_type: 'private_cabinet',
  wilaya: '',
  address: '',
  latitude: null,
  longitude: null,
  diploma: null,
  license_doc: null,
  national_id_doc: null,
  work_certificate: null,
}

export function RegistrationForm({ locale }: RegistrationFormProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<RegistrationFormData>(initialFormData)
  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const t = translations[locale]
  const dir = getDirection(locale)

  const updateField = useCallback(<K extends keyof RegistrationFormData>(
    field: K,
    value: RegistrationFormData[K]
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }, [])

  const handleFileChange = useCallback((field: 'diploma' | 'license_doc' | 'national_id_doc' | 'work_certificate', file: File | null) => {
    updateField(field, file)
  }, [updateField])

  const handleLocationSelect = useCallback((lat: number, lng: number) => {
    setFormData(prev => ({ ...prev, latitude: lat, longitude: lng }))
  }, [])

  const nextStep = () => {
    if (currentStep < 4) setCurrentStep(prev => prev + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(prev => prev - 1)
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    setErrorMessage('')

    try {
      const supabase = createClient()

      // 1. Create user account
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ??
            `${window.location.origin}/auth/callback`,
          data: {
            full_name: formData.full_name,
            provider_type: formData.provider_type,
          },
        },
      })

      if (authError) throw authError

      if (!authData.user) {
        throw new Error('Failed to create user account')
      }

      // 2. Upload documents to storage (if available)
      const uploadDocument = async (file: File | null, folder: string): Promise<string | null> => {
        if (!file) return null
        
        const fileExt = file.name.split('.').pop()
        const fileName = `${authData.user!.id}/${folder}/${Date.now()}.${fileExt}`
        
        const { error: uploadError } = await supabase.storage
          .from('provider-documents')
          .upload(fileName, file)
        
        if (uploadError) {
          console.error('Upload error:', uploadError)
          return null
        }
        
        const { data: urlData } = supabase.storage
          .from('provider-documents')
          .getPublicUrl(fileName)
        
        return urlData.publicUrl
      }

      const [diplomaUrl, licenseDocUrl, nationalIdDocUrl, workCertUrl] = await Promise.all([
        uploadDocument(formData.diploma, 'diplomas'),
        uploadDocument(formData.license_doc, 'licenses'),
        uploadDocument(formData.national_id_doc, 'national-ids'),
        uploadDocument(formData.work_certificate, 'certificates'),
      ])

      // 3. Create provider profile
      const { error: providerError } = await supabase.from('providers').insert({
        user_id: authData.user.id,
        provider_type: formData.provider_type,
        full_name: formData.full_name,
        date_of_birth: formData.date_of_birth || null,
        national_id: formData.national_id || null,
        phone: formData.phone,
        email: formData.email,
        license_number: formData.license_number,
        specialty: formData.specialty || null,
        years_of_experience: formData.years_of_experience || null,
        workplace: formData.workplace || null,
        workplace_type: formData.workplace_type || null,
        wilaya: formData.wilaya,
        address: formData.address,
        latitude: formData.latitude,
        longitude: formData.longitude,
        diploma_url: diplomaUrl,
        license_doc_url: licenseDocUrl,
        national_id_doc_url: nationalIdDocUrl,
        work_certificate_url: workCertUrl,
        status: 'pending',
      })

      if (providerError) throw providerError

      setSubmitStatus('success')
    } catch (error) {
      console.error('Registration error:', error)
      setErrorMessage(error instanceof Error ? error.message : 'Registration failed. Please try again.')
      setSubmitStatus('error')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitStatus === 'success') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
      >
        <div className="mx-auto w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mb-6">
          <Check className="h-10 w-10 text-success" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Registration Submitted!</h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          Your registration has been submitted for review. You will receive an email once your account is verified.
        </p>
        <Button
          onClick={() => window.location.href = '/'}
          className="mt-8"
        >
          Return Home
        </Button>
      </motion.div>
    )
  }

  return (
    <div className="w-full max-w-3xl mx-auto" dir={dir}>
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between relative">
          {/* Progress Line */}
          <div className="absolute top-5 left-0 right-0 h-0.5 bg-border">
            <motion.div
              className="h-full bg-primary"
              initial={{ width: '0%' }}
              animate={{ width: `${((currentStep - 1) / 3) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {STEPS.map((step) => {
            const isCompleted = currentStep > step.id
            const isCurrent = currentStep === step.id

            return (
              <div key={step.id} className="relative flex flex-col items-center z-10">
                <motion.div
                  className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors ${
                    isCompleted
                      ? 'bg-primary border-primary text-primary-foreground'
                      : isCurrent
                      ? 'bg-card border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground'
                  }`}
                  whileHover={{ scale: 1.05 }}
                >
                  {isCompleted ? (
                    <Check className="h-5 w-5" />
                  ) : (
                    <step.icon className="h-5 w-5" />
                  )}
                </motion.div>
                <span className={`mt-2 text-xs font-medium ${
                  isCurrent ? 'text-primary' : 'text-muted-foreground'
                }`}>
                  {t[step.key as keyof typeof t]}
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Form Content */}
      <div className="bg-card rounded-2xl border shadow-sm p-6 md:p-8">
        <AnimatePresence mode="wait">
          {/* Step 1: Personal Info */}
          {currentStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">{t.personalInfo}</h2>
                <p className="text-sm text-muted-foreground">
                  Enter your personal details as they appear on your official documents.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="full_name">{t.fullName} *</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => updateField('full_name', e.target.value)}
                    placeholder="Dr. Ahmed Ben Ali"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date_of_birth">{t.dateOfBirth}</Label>
                  <Input
                    id="date_of_birth"
                    type="date"
                    value={formData.date_of_birth}
                    onChange={(e) => updateField('date_of_birth', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="national_id">{t.nationalId}</Label>
                  <Input
                    id="national_id"
                    value={formData.national_id}
                    onChange={(e) => updateField('national_id', e.target.value)}
                    placeholder="123456789012345678"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">{t.phone} *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    placeholder="+213 555 123 456"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">{t.email} *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="doctor@example.com"
                    required
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="password">{t.password} *</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => updateField('password', e.target.value)}
                      placeholder="Minimum 8 characters"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 2: Professional Info */}
          {currentStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">{t.professionalInfo}</h2>
                <p className="text-sm text-muted-foreground">
                  Provide your professional credentials and work information.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2 md:col-span-2">
                  <Label>Provider Type *</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {PROVIDER_TYPES.map((type) => (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => updateField('provider_type', type.value as ProviderType)}
                        className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                          formData.provider_type === type.value
                            ? 'border-primary bg-primary/5 text-primary'
                            : 'border-border hover:border-primary/30'
                        }`}
                      >
                        <type.icon className="h-6 w-6" />
                        <span className="text-sm font-medium">{type.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="license_number">{t.licenseNumber} *</Label>
                  <Input
                    id="license_number"
                    value={formData.license_number}
                    onChange={(e) => updateField('license_number', e.target.value)}
                    placeholder="License number"
                    required
                  />
                </div>

                {formData.provider_type === 'doctor' && (
                  <div className="space-y-2">
                    <Label htmlFor="specialty">{t.specialty}</Label>
                    <select
                      id="specialty"
                      value={formData.specialty}
                      onChange={(e) => updateField('specialty', e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <option value="">Select specialty</option>
                      {SPECIALTIES.map((specialty) => (
                        <option key={specialty.value} value={specialty.value}>
                          {specialty.label}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="years_of_experience">{t.yearsExperience}</Label>
                  <Input
                    id="years_of_experience"
                    type="number"
                    min="0"
                    max="60"
                    value={formData.years_of_experience || ''}
                    onChange={(e) => updateField('years_of_experience', parseInt(e.target.value) || 0)}
                    placeholder="5"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="workplace">{t.workplace}</Label>
                  <Input
                    id="workplace"
                    value={formData.workplace}
                    onChange={(e) => updateField('workplace', e.target.value)}
                    placeholder="Hospital or clinic name"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label>{t.workplaceType}</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {WORKPLACE_TYPES.map((type) => (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => updateField('workplace_type', type.value as WorkplaceType)}
                        className={`px-4 py-2.5 rounded-lg border-2 text-sm font-medium transition-all ${
                          formData.workplace_type === type.value
                            ? 'border-primary bg-primary/5 text-primary'
                            : 'border-border hover:border-primary/30'
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Location */}
          {currentStep === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">{t.locationInfo}</h2>
                <p className="text-sm text-muted-foreground">
                  Set your practice location for patients to find you.
                </p>
              </div>

              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wilaya">{t.wilaya} *</Label>
                  <select
                    id="wilaya"
                    value={formData.wilaya}
                    onChange={(e) => updateField('wilaya', e.target.value)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    required
                  >
                    <option value="">Select wilaya</option>
                    {WILAYAS.map((wilaya) => (
                      <option key={wilaya.code} value={wilaya.code}>
                        {wilaya.code} - {wilaya.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">{t.address} *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => updateField('address', e.target.value)}
                    placeholder="123 Rue Didouche Mourad, Algiers"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Location on Map</Label>
                  <LocationPicker
                    latitude={formData.latitude}
                    longitude={formData.longitude}
                    onLocationSelect={handleLocationSelect}
                  />
                  {formData.latitude && formData.longitude && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Coordinates: {formData.latitude.toFixed(6)}, {formData.longitude.toFixed(6)}
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 4: Documents */}
          {currentStep === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">{t.documents}</h2>
                <p className="text-sm text-muted-foreground">
                  Upload your professional documents for verification. Accepted formats: PDF, JPG, PNG
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <FileUpload
                  label={t.diploma}
                  file={formData.diploma}
                  onChange={(file) => handleFileChange('diploma', file)}
                  required
                />
                <FileUpload
                  label={t.licenseDoc}
                  file={formData.license_doc}
                  onChange={(file) => handleFileChange('license_doc', file)}
                  required
                />
                <FileUpload
                  label={t.nationalIdDoc}
                  file={formData.national_id_doc}
                  onChange={(file) => handleFileChange('national_id_doc', file)}
                  required
                />
                <FileUpload
                  label={t.workCertificate}
                  file={formData.work_certificate}
                  onChange={(file) => handleFileChange('work_certificate', file)}
                />
              </div>

              {errorMessage && (
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                  {errorMessage}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
            className="gap-2"
          >
            <ChevronLeft className="h-4 w-4" />
            {t.previous}
          </Button>

          {currentStep < 4 ? (
            <Button onClick={nextStep} className="gap-2">
              {t.next}
              <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  {t.submit}
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

// File Upload Component
interface FileUploadProps {
  label: string
  file: File | null
  onChange: (file: File | null) => void
  required?: boolean
}

function FileUpload({ label, file, onChange, required }: FileUploadProps) {
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile) onChange(droppedFile)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) onChange(selectedFile)
  }

  return (
    <div className="space-y-2">
      <Label className="flex items-center gap-1">
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-xl p-6 transition-colors ${
          file ? 'border-success bg-success/5' : 'border-border hover:border-primary/50'
        }`}
      >
        {file ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                <Check className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm font-medium truncate max-w-[200px]">{file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onChange(null)}
              className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <label className="flex flex-col items-center gap-2 cursor-pointer">
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Upload className="h-6 w-6 text-primary" />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium">Drop file here or click to upload</p>
              <p className="text-xs text-muted-foreground">PDF, JPG, PNG up to 10MB</p>
            </div>
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleChange}
              className="sr-only"
            />
          </label>
        )}
      </div>
    </div>
  )
}
