'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Stethoscope, Globe, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { type Locale, translations, getDirection } from '@/lib/i18n'

interface NavbarProps {
  locale: Locale
  onLocaleChange: (locale: Locale) => void
}

export function Navbar({ locale, onLocaleChange }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [showLangMenu, setShowLangMenu] = useState(false)
  const t = translations[locale]
  const dir = getDirection(locale)

  const navLinks = [
    { href: '/', label: t.home },
    { href: '/find', label: t.findDoctors },
    { href: '/register', label: t.forProviders },
    { href: '/admin', label: t.admin },
  ]

  const languages = [
    { code: 'en' as Locale, label: 'English', flag: 'EN' },
    { code: 'fr' as Locale, label: 'Français', flag: 'FR' },
    { code: 'ar' as Locale, label: 'العربية', flag: 'AR' },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass" dir={dir}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-transform group-hover:scale-105">
              <Stethoscope className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              SehaTech
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="relative px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground group"
              >
                {link.label}
                <span className="absolute inset-x-4 bottom-0 h-0.5 bg-primary scale-x-0 transition-transform group-hover:scale-x-100" />
              </Link>
            ))}
          </div>

          {/* Right Side */}
          <div className="hidden md:flex md:items-center md:gap-3">
            {/* Language Selector */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-1"
              >
                <Globe className="h-4 w-4" />
                <span className="text-xs font-semibold">
                  {languages.find(l => l.code === locale)?.flag}
                </span>
                <ChevronDown className="h-3 w-3" />
              </Button>
              
              <AnimatePresence>
                {showLangMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute right-0 mt-2 w-40 rounded-xl bg-card border shadow-lg overflow-hidden"
                  >
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          onLocaleChange(lang.code)
                          setShowLangMenu(false)
                        }}
                        className={`w-full px-4 py-2.5 text-sm text-left hover:bg-accent transition-colors flex items-center justify-between ${
                          locale === lang.code ? 'bg-accent text-primary font-medium' : ''
                        }`}
                      >
                        {lang.label}
                        <span className="text-xs text-muted-foreground">{lang.flag}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Link href="/auth/login">
              <Button variant="ghost" size="sm">
                {t.login}
              </Button>
            </Link>
            <Link href="/register">
              <Button size="sm" className="rounded-full px-6">
                {t.register}
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t bg-card/95 backdrop-blur-lg"
          >
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="block px-4 py-3 rounded-lg text-sm font-medium hover:bg-accent transition-colors"
                >
                  {link.label}
                </Link>
              ))}
              
              <div className="pt-4 border-t flex flex-col gap-2">
                <div className="flex gap-2 px-4">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => onLocaleChange(lang.code)}
                      className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                        locale === lang.code 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-accent hover:bg-accent/80'
                      }`}
                    >
                      {lang.flag}
                    </button>
                  ))}
                </div>
                <Link href="/auth/login" className="w-full">
                  <Button variant="outline" className="w-full">
                    {t.login}
                  </Button>
                </Link>
                <Link href="/register" className="w-full">
                  <Button className="w-full">
                    {t.register}
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
