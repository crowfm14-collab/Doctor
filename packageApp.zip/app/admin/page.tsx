'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Stethoscope, Users, Clock, CheckCircle, XCircle, AlertTriangle,
  Search, Filter, Eye, ChevronRight, BarChart3, TrendingUp, FileText,
  Loader2, X, Check, Ban
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { createClient } from '@/lib/supabase/client'
import { type Provider, type ProviderStatus } from '@/lib/types'
import { SPECIALTIES, WILAYAS, STATUS_COLORS } from '@/lib/constants'

type TabType = 'all' | 'pending' | 'verified' | 'rejected'

export default function AdminDashboard() {
  const [providers, setProviders] = useState<Provider[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<TabType>('pending')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [actionLoading, setActionLoading] = useState(false)

  // Statistics
  const stats = {
    total: providers.length,
    pending: providers.filter(p => p.status === 'pending').length,
    verified: providers.filter(p => p.status === 'verified').length,
    rejected: providers.filter(p => p.status === 'rejected').length,
  }

  useEffect(() => {
    fetchProviders()
  }, [])

  async function fetchProviders() {
    setLoading(true)
    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from('providers')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setProviders(data || [])
    } catch (error) {
      console.error('Error fetching providers:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredProviders = providers.filter(provider => {
    // Filter by tab
    if (activeTab !== 'all' && provider.status !== activeTab) return false
    
    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        provider.full_name.toLowerCase().includes(query) ||
        provider.email.toLowerCase().includes(query) ||
        provider.license_number.toLowerCase().includes(query)
      )
    }
    
    return true
  })

  async function updateProviderStatus(providerId: string, status: ProviderStatus, reason?: string) {
    setActionLoading(true)
    try {
      const supabase = createClient()
      
      const updateData: Record<string, unknown> = { 
        status,
        ...(status === 'verified' && { verified_at: new Date().toISOString() }),
        ...(status === 'rejected' && reason && { rejection_reason: reason }),
      }
      
      const { error } = await supabase
        .from('providers')
        .update(updateData)
        .eq('id', providerId)

      if (error) throw error
      
      // Update local state
      setProviders(prev => prev.map(p => 
        p.id === providerId ? { ...p, status, rejection_reason: reason || null } as Provider : p
      ))
      
      setSelectedProvider(null)
      setShowRejectModal(false)
      setRejectReason('')
    } catch (error) {
      console.error('Error updating provider status:', error)
      alert('Failed to update provider status')
    } finally {
      setActionLoading(false)
    }
  }

  const tabs = [
    { id: 'pending' as TabType, label: 'Pending Review', icon: Clock, count: stats.pending },
    { id: 'verified' as TabType, label: 'Verified', icon: CheckCircle, count: stats.verified },
    { id: 'rejected' as TabType, label: 'Rejected', icon: XCircle, count: stats.rejected },
    { id: 'all' as TabType, label: 'All Providers', icon: Users, count: stats.total },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <Stethoscope className="h-5 w-5" />
                </div>
                <span className="text-xl font-bold">SehaTech</span>
              </Link>
              <div className="h-6 w-px bg-border" />
              <span className="text-sm font-medium text-muted-foreground">Admin Dashboard</span>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          {[
            { label: 'Total Providers', value: stats.total, icon: Users, color: 'text-primary' },
            { label: 'Pending Review', value: stats.pending, icon: Clock, color: 'text-warning' },
            { label: 'Verified', value: stats.verified, icon: CheckCircle, color: 'text-success' },
            { label: 'Rejected', value: stats.rejected, icon: XCircle, color: 'text-destructive' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card rounded-2xl border p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-xl bg-muted ${stat.color}`}>
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tabs & Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'bg-card border hover:bg-accent'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  activeTab === tab.id ? 'bg-primary-foreground/20' : 'bg-muted'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          <div className="relative flex-1 sm:max-w-xs ml-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search providers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Providers Table */}
        <div className="bg-card rounded-2xl border overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredProviders.length === 0 ? (
            <div className="text-center py-20">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No providers found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50 border-b">
                  <tr>
                    <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Provider</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Type</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Wilaya</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Status</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Registered</th>
                    <th className="text-right px-6 py-4 text-sm font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredProviders.map((provider) => {
                    const specialty = SPECIALTIES.find(s => s.value === provider.specialty)
                    const wilaya = WILAYAS.find(w => w.code === provider.wilaya)
                    const statusStyle = STATUS_COLORS[provider.status]

                    return (
                      <motion.tr
                        key={provider.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="hover:bg-muted/30 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                              {specialty?.icon && <specialty.icon className="h-5 w-5" />}
                            </div>
                            <div>
                              <p className="font-medium">{provider.full_name}</p>
                              <p className="text-sm text-muted-foreground">{provider.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="capitalize text-sm">{provider.provider_type}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm">{wilaya?.name || provider.wilaya}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusStyle.bg} ${statusStyle.text}`}>
                            {provider.status === 'pending' && <Clock className="h-3 w-3" />}
                            {provider.status === 'verified' && <CheckCircle className="h-3 w-3" />}
                            {provider.status === 'rejected' && <XCircle className="h-3 w-3" />}
                            {provider.status === 'suspended' && <Ban className="h-3 w-3" />}
                            <span className="capitalize">{provider.status}</span>
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-muted-foreground">
                            {new Date(provider.created_at).toLocaleDateString()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedProvider(provider)}
                            className="gap-1"
                          >
                            <Eye className="h-4 w-4" />
                            View
                          </Button>
                        </td>
                      </motion.tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Provider Detail Modal */}
      <AnimatePresence>
        {selectedProvider && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
            onClick={() => setSelectedProvider(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-card rounded-2xl border shadow-xl"
            >
              <div className="sticky top-0 flex items-center justify-between p-6 border-b bg-card z-10">
                <div>
                  <h3 className="text-lg font-semibold">{selectedProvider.full_name}</h3>
                  <p className="text-sm text-muted-foreground">{selectedProvider.email}</p>
                </div>
                <button
                  onClick={() => setSelectedProvider(null)}
                  className="p-2 rounded-lg hover:bg-muted transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Status Badge */}
                <div className="flex items-center gap-3">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${STATUS_COLORS[selectedProvider.status].bg} ${STATUS_COLORS[selectedProvider.status].text}`}>
                    {selectedProvider.status === 'pending' && <Clock className="h-4 w-4" />}
                    {selectedProvider.status === 'verified' && <CheckCircle className="h-4 w-4" />}
                    {selectedProvider.status === 'rejected' && <XCircle className="h-4 w-4" />}
                    <span className="capitalize">{selectedProvider.status}</span>
                  </span>
                  {selectedProvider.rejection_reason && (
                    <span className="text-sm text-destructive">
                      Reason: {selectedProvider.rejection_reason}
                    </span>
                  )}
                </div>

                {/* Provider Details Grid */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <DetailItem label="Provider Type" value={selectedProvider.provider_type} />
                  <DetailItem label="License Number" value={selectedProvider.license_number} />
                  <DetailItem label="Specialty" value={SPECIALTIES.find(s => s.value === selectedProvider.specialty)?.label || 'N/A'} />
                  <DetailItem label="Experience" value={selectedProvider.years_of_experience ? `${selectedProvider.years_of_experience} years` : 'N/A'} />
                  <DetailItem label="Phone" value={selectedProvider.phone} />
                  <DetailItem label="National ID" value={selectedProvider.national_id || 'N/A'} />
                  <DetailItem label="Wilaya" value={WILAYAS.find(w => w.code === selectedProvider.wilaya)?.name || selectedProvider.wilaya} />
                  <DetailItem label="Workplace" value={selectedProvider.workplace || 'N/A'} />
                  <DetailItem label="Address" value={selectedProvider.address} className="sm:col-span-2" />
                </div>

                {/* Documents */}
                <div>
                  <h4 className="font-medium mb-3">Uploaded Documents</h4>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {selectedProvider.diploma_url && (
                      <DocumentLink label="Medical Diploma" url={selectedProvider.diploma_url} />
                    )}
                    {selectedProvider.license_doc_url && (
                      <DocumentLink label="License Document" url={selectedProvider.license_doc_url} />
                    )}
                    {selectedProvider.national_id_doc_url && (
                      <DocumentLink label="National ID" url={selectedProvider.national_id_doc_url} />
                    )}
                    {selectedProvider.work_certificate_url && (
                      <DocumentLink label="Work Certificate" url={selectedProvider.work_certificate_url} />
                    )}
                  </div>
                </div>

                {/* Location */}
                {selectedProvider.latitude && selectedProvider.longitude && (
                  <div>
                    <h4 className="font-medium mb-2">Location</h4>
                    <p className="text-sm text-muted-foreground">
                      Coordinates: {selectedProvider.latitude.toFixed(6)}, {selectedProvider.longitude.toFixed(6)}
                    </p>
                  </div>
                )}

                {/* Actions */}
                {selectedProvider.status === 'pending' && (
                  <div className="flex gap-3 pt-4 border-t">
                    <Button
                      className="flex-1 gap-2"
                      onClick={() => updateProviderStatus(selectedProvider.id, 'verified')}
                      disabled={actionLoading}
                    >
                      {actionLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                      Approve
                    </Button>
                    <Button
                      variant="destructive"
                      className="flex-1 gap-2"
                      onClick={() => setShowRejectModal(true)}
                      disabled={actionLoading}
                    >
                      <XCircle className="h-4 w-4" />
                      Reject
                    </Button>
                  </div>
                )}

                {selectedProvider.status === 'verified' && (
                  <div className="flex gap-3 pt-4 border-t">
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={() => updateProviderStatus(selectedProvider.id, 'suspended')}
                      disabled={actionLoading}
                    >
                      <Ban className="h-4 w-4" />
                      Suspend
                    </Button>
                  </div>
                )}

                {selectedProvider.status === 'suspended' && (
                  <div className="flex gap-3 pt-4 border-t">
                    <Button
                      className="flex-1 gap-2"
                      onClick={() => updateProviderStatus(selectedProvider.id, 'verified')}
                      disabled={actionLoading}
                    >
                      <Check className="h-4 w-4" />
                      Reactivate
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reject Modal */}
      <AnimatePresence>
        {showRejectModal && selectedProvider && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
            onClick={() => setShowRejectModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md bg-card rounded-2xl border shadow-xl p-6"
            >
              <h3 className="text-lg font-semibold mb-4">Reject Provider</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Please provide a reason for rejecting {selectedProvider.full_name}&apos;s registration.
              </p>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Enter rejection reason..."
                className="flex min-h-[100px] w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring mb-4"
              />
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowRejectModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  onClick={() => updateProviderStatus(selectedProvider.id, 'rejected', rejectReason)}
                  disabled={!rejectReason.trim() || actionLoading}
                >
                  {actionLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    'Reject'
                  )}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function DetailItem({ label, value, className = '' }: { label: string; value: string; className?: string }) {
  return (
    <div className={className}>
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="font-medium capitalize">{value}</p>
    </div>
  )
}

function DocumentLink({ label, url }: { label: string; url: string }) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 p-3 rounded-lg border hover:bg-accent transition-colors"
    >
      <FileText className="h-5 w-5 text-primary" />
      <span className="text-sm font-medium">{label}</span>
      <ChevronRight className="h-4 w-4 ml-auto text-muted-foreground" />
    </a>
  )
}
