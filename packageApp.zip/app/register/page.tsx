'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { ArrowLeft, Stethoscope, Shield, Clock, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { RegistrationForm } from '@/components/registration/registration-form'
import { type Locale, translations, getDirection } from '@/lib/i18n'

export default function RegisterPage() {
  const [locale, setLocale] = useState<Locale>('en')
  const t = translations[locale]
  const dir = getDirection(locale)

  const benefits = [
    { icon: Shield, title: 'Verified Profile', desc: 'Get a verified badge to build trust with patients' },
    { icon: Users, title: 'Reach More Patients', desc: 'Connect with thousands of patients across Algeria' },
    { icon: Clock, title: 'Easy Scheduling', desc: 'Manage your appointments efficiently online' },
  ]

  return (
    <div className="min-h-screen bg-background" dir={dir}>
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <Stethoscope className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold">SehaTech</span>
            </Link>

            <div className="flex items-center gap-3">
              <select
                value={locale}
                onChange={(e) => setLocale(e.target.value as Locale)}
                className="text-sm bg-transparent border rounded-lg px-2 py-1"
              >
                <option value="en">EN</option>
                <option value="fr">FR</option>
                <option value="ar">AR</option>
              </select>
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-5">
            {/* Left Side - Benefits */}
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="sticky top-24"
              >
                <h1 className="text-3xl font-bold mb-4">{t.registerAsProvider}</h1>
                <p className="text-muted-foreground mb-8">
                  Join the largest healthcare network in Algeria. Register your practice and start receiving patients today.
                </p>

                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <motion.div
                      key={benefit.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex gap-4 p-4 rounded-xl bg-card border hover:shadow-md transition-shadow"
                    >
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary shrink-0">
                        <benefit.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{benefit.title}</h3>
                        <p className="text-sm text-muted-foreground">{benefit.desc}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-8 p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <p className="text-sm text-muted-foreground">
                    <strong className="text-foreground">Note:</strong> Your profile will be reviewed by our team before being published. This usually takes 1-3 business days.
                  </p>
                </div>
              </motion.div>
            </div>

            {/* Right Side - Form */}
            <div className="lg:col-span-3">
              <RegistrationForm locale={locale} />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
