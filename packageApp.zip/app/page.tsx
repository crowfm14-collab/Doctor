'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { HeroSection } from '@/components/hero-section'
import { type Locale } from '@/lib/i18n'

export default function HomePage() {
  const [locale, setLocale] = useState<Locale>('en')

  return (
    <main className="min-h-screen">
      <Navbar locale={locale} onLocaleChange={setLocale} />
      <HeroSection locale={locale} />
    </main>
  )
}
