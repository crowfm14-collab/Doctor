import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const specialty = searchParams.get('specialty')
    const wilaya = searchParams.get('wilaya')
    const type = searchParams.get('type')
    
    const supabase = await createClient()
    
    let query = supabase
      .from('providers')
      .select('*')
      .order('average_rating', { ascending: false })
    
    // Only show verified providers for public access
    if (status) {
      query = query.eq('status', status)
    } else {
      query = query.eq('status', 'verified')
    }
    
    if (specialty) {
      query = query.eq('specialty', specialty)
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya)
    }
    
    if (type) {
      query = query.eq('provider_type', type)
    }
    
    const { data, error } = await query
    
    if (error) throw error
    
    return NextResponse.json({ providers: data })
  } catch (error) {
    console.error('Error fetching providers:', error)
    return NextResponse.json(
      { error: 'Failed to fetch providers' },
      { status: 500 }
    )
  }
}
