import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { provider_id, patient_name, patient_phone, patient_email, appointment_date, appointment_time, notes } = body
    
    // Validation
    if (!provider_id || !patient_name || !patient_phone || !appointment_date || !appointment_time) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }
    
    const supabase = await createClient()
    
    // Check if provider exists and is verified
    const { data: provider, error: providerError } = await supabase
      .from('providers')
      .select('id, status')
      .eq('id', provider_id)
      .eq('status', 'verified')
      .single()
    
    if (providerError || !provider) {
      return NextResponse.json(
        { error: 'Provider not found or not verified' },
        { status: 404 }
      )
    }
    
    // Create appointment
    const { data: appointment, error } = await supabase
      .from('appointments')
      .insert({
        provider_id,
        patient_name,
        patient_phone,
        patient_email: patient_email || null,
        appointment_date,
        appointment_time,
        notes: notes || null,
        status: 'pending',
      })
      .select()
      .single()
    
    if (error) throw error
    
    return NextResponse.json({ appointment }, { status: 201 })
  } catch (error) {
    console.error('Error creating appointment:', error)
    return NextResponse.json(
      { error: 'Failed to create appointment' },
      { status: 500 }
    )
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const providerId = searchParams.get('provider_id')
    
    if (!providerId) {
      return NextResponse.json(
        { error: 'Provider ID required' },
        { status: 400 }
      )
    }
    
    const supabase = await createClient()
    
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('provider_id', providerId)
      .order('appointment_date', { ascending: true })
    
    if (error) throw error
    
    return NextResponse.json({ appointments: data })
  } catch (error) {
    console.error('Error fetching appointments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch appointments' },
      { status: 500 }
    )
  }
}
