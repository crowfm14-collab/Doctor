'use client'

import { useState, useEffect, use } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  ArrowLeft, Star, MapPin, Phone, Mail, Clock, Calendar, 
  BadgeCheck, Building2, Briefcase, User, X, Check, Loader2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { createClient } from '@/lib/supabase/client'
import { type Provider, type Review, type AvailabilitySlot } from '@/lib/types'
import { SPECIALTIES, WILAYAS, DAYS_OF_WEEK } from '@/lib/constants'

export default function DoctorProfilePage({ 
  params 
}: { 
  params: Promise<{ id: string }> 
}) {
  const { id } = use(params)
  const searchParams = useSearchParams()
  const showBookingModal = searchParams.get('book') === 'true'
  
  const [provider, setProvider] = useState<Provider | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [availability, setAvailability] = useState<AvailabilitySlot[]>([])
  const [loading, setLoading] = useState(true)
  const [showBooking, setShowBooking] = useState(showBookingModal)
  const [bookingSuccess, setBookingSuccess] = useState(false)
  
  // Booking form state
  const [bookingForm, setBookingForm] = useState({
    date: '',
    time: '',
    name: '',
    phone: '',
    email: '',
    notes: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    async function fetchData() {
      setLoading(true)
      try {
        const supabase = createClient()
        
        // Fetch provider
        const { data: providerData, error: providerError } = await supabase
          .from('providers')
          .select('*')
          .eq('id', id)
          .eq('status', 'verified')
          .single()

        if (providerError) throw providerError
        setProvider(providerData)

        // Fetch reviews
        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('*')
          .eq('provider_id', id)
          .order('created_at', { ascending: false })
          .limit(10)

        setReviews(reviewsData || [])

        // Fetch availability
        const { data: availabilityData } = await supabase
          .from('availability_slots')
          .select('*')
          .eq('provider_id', id)
          .eq('is_available', true)
          .order('day_of_week')

        setAvailability(availabilityData || [])
      } catch (error) {
        console.error('Error fetching provider:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [id])

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const supabase = createClient()
      
      const { error } = await supabase.from('appointments').insert({
        provider_id: id,
        patient_name: bookingForm.name,
        patient_phone: bookingForm.phone,
        patient_email: bookingForm.email || null,
        appointment_date: bookingForm.date,
        appointment_time: bookingForm.time,
        notes: bookingForm.notes || null,
        status: 'pending',
      })

      if (error) throw error
      
      setBookingSuccess(true)
      setTimeout(() => {
        setShowBooking(false)
        setBookingSuccess(false)
        setBookingForm({ date: '', time: '', name: '', phone: '', email: '', notes: '' })
      }, 3000)
    } catch (error) {
      console.error('Booking error:', error)
      alert('Failed to book appointment. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!provider) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">Provider not found</h1>
        <Link href="/find">
          <Button>Back to Search</Button>
        </Link>
      </div>
    )
  }

  const specialty = SPECIALTIES.find(s => s.value === provider.specialty)
  const wilaya = WILAYAS.find(w => w.code === provider.wilaya)
  const SpecialtyIcon = specialty?.icon

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-b">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/find">
            <Button variant="ghost" size="sm" className="gap-2 mb-6">
              <ArrowLeft className="h-4 w-4" />
              Back to Search
            </Button>
          </Link>

          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
            {/* Avatar */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex h-24 w-24 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg"
            >
              {SpecialtyIcon && <SpecialtyIcon className="h-12 w-12" />}
            </motion.div>

            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl md:text-3xl font-bold">{provider.full_name}</h1>
                {provider.status === 'verified' && (
                  <BadgeCheck className="h-6 w-6 text-primary fill-primary/20" />
                )}
              </div>
              
              {specialty && (
                <p className="text-lg text-muted-foreground mt-1">{specialty.label}</p>
              )}

              <div className="flex items-center gap-4 mt-3 flex-wrap">
                {provider.average_rating > 0 && (
                  <div className="flex items-center gap-1.5">
                    <Star className="h-5 w-5 fill-warning text-warning" />
                    <span className="font-semibold">{provider.average_rating.toFixed(1)}</span>
                    <span className="text-muted-foreground">({provider.total_ratings} reviews)</span>
                  </div>
                )}
                
                {provider.years_of_experience && (
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{provider.years_of_experience} years exp.</span>
                  </div>
                )}

                {wilaya && (
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{wilaya.name}</span>
                  </div>
                )}
              </div>
            </div>

            <Button 
              size="lg" 
              onClick={() => setShowBooking(true)}
              className="gap-2 rounded-xl px-8"
            >
              <Calendar className="h-5 w-5" />
              Book Appointment
            </Button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* About */}
            <section className="bg-card rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                About
              </h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {provider.workplace && (
                  <div className="flex items-start gap-3">
                    <Building2 className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-sm text-muted-foreground">Workplace</p>
                      <p className="font-medium">{provider.workplace}</p>
                    </div>
                  </div>
                )}
                {provider.years_of_experience && (
                  <div className="flex items-start gap-3">
                    <Briefcase className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-sm text-muted-foreground">Experience</p>
                      <p className="font-medium">{provider.years_of_experience} years</p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Availability */}
            {availability.length > 0 && (
              <section className="bg-card rounded-2xl border p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Availability
                </h2>
                <div className="grid gap-2">
                  {availability.map((slot) => {
                    const day = DAYS_OF_WEEK.find(d => d.value === slot.day_of_week)
                    return (
                      <div 
                        key={slot.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                      >
                        <span className="font-medium">{day?.label}</span>
                        <span className="text-muted-foreground">
                          {slot.start_time.slice(0, 5)} - {slot.end_time.slice(0, 5)}
                        </span>
                      </div>
                    )
                  })}
                </div>
              </section>
            )}

            {/* Reviews */}
            <section className="bg-card rounded-2xl border p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" />
                Reviews ({reviews.length})
              </h2>
              
              {reviews.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No reviews yet. Be the first to review!
                </p>
              ) : (
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="p-4 rounded-xl bg-muted/50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{review.reviewer_name}</span>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star 
                              key={i}
                              className={`h-4 w-4 ${
                                i < review.rating 
                                  ? 'fill-warning text-warning' 
                                  : 'text-muted-foreground'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      {review.comment && (
                        <p className="text-sm text-muted-foreground">{review.comment}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(review.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <div className="bg-card rounded-2xl border p-6 sticky top-24">
              <h3 className="font-semibold mb-4">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <a href={`tel:${provider.phone}`} className="font-medium hover:text-primary">
                      {provider.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <a href={`mailto:${provider.email}`} className="font-medium hover:text-primary">
                      {provider.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Address</p>
                    <p className="font-medium">{provider.address}</p>
                  </div>
                </div>
              </div>

              <Button 
                className="w-full mt-6 gap-2" 
                size="lg"
                onClick={() => setShowBooking(true)}
              >
                <Calendar className="h-5 w-5" />
                Book Appointment
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* Booking Modal */}
      <AnimatePresence>
        {showBooking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
            onClick={() => setShowBooking(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md bg-card rounded-2xl border shadow-xl"
            >
              {bookingSuccess ? (
                <div className="p-8 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="mx-auto w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mb-4"
                  >
                    <Check className="h-8 w-8 text-success" />
                  </motion.div>
                  <h3 className="text-xl font-semibold mb-2">Appointment Requested!</h3>
                  <p className="text-muted-foreground">
                    You will receive a confirmation once the doctor accepts your appointment.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between p-6 border-b">
                    <h3 className="text-lg font-semibold">Book Appointment</h3>
                    <button
                      onClick={() => setShowBooking(false)}
                      className="p-2 rounded-lg hover:bg-muted transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  <form onSubmit={handleBookingSubmit} className="p-6 space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="date">Date *</Label>
                        <Input
                          id="date"
                          type="date"
                          value={bookingForm.date}
                          onChange={(e) => setBookingForm(prev => ({ ...prev, date: e.target.value }))}
                          min={new Date().toISOString().split('T')[0]}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="time">Time *</Label>
                        <Input
                          id="time"
                          type="time"
                          value={bookingForm.time}
                          onChange={(e) => setBookingForm(prev => ({ ...prev, time: e.target.value }))}
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="name">Your Name *</Label>
                      <Input
                        id="name"
                        value={bookingForm.name}
                        onChange={(e) => setBookingForm(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Full name"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={bookingForm.phone}
                        onChange={(e) => setBookingForm(prev => ({ ...prev, phone: e.target.value }))}
                        placeholder="+213 XXX XXX XXX"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email (Optional)</Label>
                      <Input
                        id="email"
                        type="email"
                        value={bookingForm.email}
                        onChange={(e) => setBookingForm(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="your@email.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="notes">Notes (Optional)</Label>
                      <textarea
                        id="notes"
                        value={bookingForm.notes}
                        onChange={(e) => setBookingForm(prev => ({ ...prev, notes: e.target.value }))}
                        placeholder="Reason for visit, symptoms, etc."
                        className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          Booking...
                        </>
                      ) : (
                        'Confirm Booking'
                      )}
                    </Button>
                  </form>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
