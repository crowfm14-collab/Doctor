'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { AlertCircle, ArrowLeft, Stethoscope } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Suspense } from 'react'

function ErrorContent() {
  const searchParams = useSearchParams()
  const error = searchParams.get('error')

  return (
    <div className="text-center max-w-md">
      <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
        <AlertCircle className="h-8 w-8 text-destructive" />
      </div>

      <h1 className="text-2xl font-bold mb-2">Authentication Error</h1>
      <p className="text-muted-foreground mb-6">
        {error || 'An error occurred during authentication. Please try again.'}
      </p>

      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Link href="/auth/login">
          <Button variant="outline" className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Login
          </Button>
        </Link>
        <Link href="/">
          <Button className="gap-2">
            <Stethoscope className="h-4 w-4" />
            Go to Home
          </Button>
        </Link>
      </div>
    </div>
  )
}

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <Suspense fallback={
        <div className="text-center max-w-md">
          <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
            <AlertCircle className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Authentication Error</h1>
          <p className="text-muted-foreground mb-6">Loading error details...</p>
        </div>
      }>
        <ErrorContent />
      </Suspense>
    </div>
  )
}
