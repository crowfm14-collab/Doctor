'use client'

import { useState, useEffect, useMemo, useCallback, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { Stethoscope, Map, List, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SearchFiltersComponent, type SearchFilters } from '@/components/search-filters'
import { ProviderCard } from '@/components/provider-card'
import { ProvidersMap } from '@/components/map/providers-map'
import { createClient } from '@/lib/supabase/client'
import { type Provider, type ProviderType } from '@/lib/types'

function FindPageContent() {
  const searchParams = useSearchParams()
  const [providers, setProviders] = useState<Provider[]>([])
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState<'list' | 'map' | 'split'>('split')
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)

  const [filters, setFilters] = useState<SearchFilters>({
    query: searchParams.get('q') || '',
    specialty: searchParams.get('specialty') || '',
    wilaya: searchParams.get('wilaya') || '',
    providerType: (searchParams.get('type') as ProviderType) || '',
    nearMe: false,
  })

  // Fetch verified providers
  useEffect(() => {
    async function fetchProviders() {
      setLoading(true)
      try {
        const supabase = createClient()
        const { data, error } = await supabase
          .from('providers')
          .select('*')
          .eq('status', 'verified')
          .order('average_rating', { ascending: false })

        if (error) throw error
        setProviders(data || [])
      } catch (error) {
        console.error('Error fetching providers:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchProviders()
  }, [])

  // Get user location when nearMe is enabled
  useEffect(() => {
    if (filters.nearMe && !userLocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
        },
        (error) => {
          console.error('Error getting location:', error)
          setFilters(prev => ({ ...prev, nearMe: false }))
        }
      )
    }
  }, [filters.nearMe, userLocation])

  // Calculate distance between two points
  const calculateDistance = useCallback((lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371 // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLng = (lng2 - lng1) * Math.PI / 180
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c
  }, [])

  // Filter providers
  const filteredProviders = useMemo(() => {
    let result = providers

    // Filter by query
    if (filters.query) {
      const query = filters.query.toLowerCase()
      result = result.filter(p => 
        p.full_name.toLowerCase().includes(query) ||
        p.specialty?.toLowerCase().includes(query) ||
        p.address.toLowerCase().includes(query) ||
        p.workplace?.toLowerCase().includes(query)
      )
    }

    // Filter by specialty
    if (filters.specialty) {
      result = result.filter(p => p.specialty === filters.specialty)
    }

    // Filter by wilaya
    if (filters.wilaya) {
      result = result.filter(p => p.wilaya === filters.wilaya)
    }

    // Filter by provider type
    if (filters.providerType) {
      result = result.filter(p => p.provider_type === filters.providerType)
    }

    // Sort by distance if nearMe is enabled
    if (filters.nearMe && userLocation) {
      result = result
        .filter(p => p.latitude && p.longitude)
        .map(p => ({
          ...p,
          distance: calculateDistance(userLocation.lat, userLocation.lng, p.latitude!, p.longitude!)
        }))
        .sort((a, b) => a.distance - b.distance)
        .filter(p => p.distance <= 50) // Within 50km
    }

    return result
  }, [providers, filters, userLocation, calculateDistance])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <Stethoscope className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold">SehaTech</span>
            </Link>

            {/* View Mode Toggle */}
            <div className="flex items-center gap-2 bg-muted p-1 rounded-lg">
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="gap-2"
              >
                <List className="h-4 w-4" />
                <span className="hidden sm:inline">List</span>
              </Button>
              <Button
                variant={viewMode === 'split' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('split')}
                className="hidden md:flex gap-2"
              >
                <span className="hidden sm:inline">Split</span>
              </Button>
              <Button
                variant={viewMode === 'map' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('map')}
                className="gap-2"
              >
                <Map className="h-4 w-4" />
                <span className="hidden sm:inline">Map</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        {/* Search Filters */}
        <SearchFiltersComponent
          filters={filters}
          onFiltersChange={setFilters}
          resultCount={filteredProviders.length}
        />

        {/* Content */}
        <div className="mt-6">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
                <p className="text-muted-foreground">Loading providers...</p>
              </div>
            </div>
          ) : filteredProviders.length === 0 ? (
            <div className="text-center py-20">
              <div className="mx-auto w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
                <Stethoscope className="h-10 w-10 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No providers found</h3>
              <p className="text-muted-foreground">
                Try adjusting your filters or search query
              </p>
            </div>
          ) : viewMode === 'list' ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <AnimatePresence mode="popLayout">
                {filteredProviders.map((provider, index) => (
                  <motion.div
                    key={provider.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <ProviderCard provider={provider} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : viewMode === 'map' ? (
            <div className="h-[calc(100vh-220px)] rounded-xl overflow-hidden border">
              <ProvidersMap
                providers={filteredProviders}
                selectedProvider={selectedProvider}
                onProviderSelect={setSelectedProvider}
              />
            </div>
          ) : (
            // Split View
            <div className="flex gap-6 h-[calc(100vh-220px)]">
              {/* Providers List */}
              <div className="w-96 shrink-0 overflow-y-auto space-y-3 pr-2 hidden md:block">
                {filteredProviders.map((provider) => (
                  <ProviderCard
                    key={provider.id}
                    provider={provider}
                    variant="compact"
                    isSelected={selectedProvider?.id === provider.id}
                    onSelect={setSelectedProvider}
                  />
                ))}
              </div>

              {/* Map */}
              <div className="flex-1 rounded-xl overflow-hidden border">
                <ProvidersMap
                  providers={filteredProviders}
                  selectedProvider={selectedProvider}
                  onProviderSelect={setSelectedProvider}
                />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function FindPageFallback() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
        <p className="text-muted-foreground">Loading...</p>
      </div>
    </div>
  )
}

export default function FindPage() {
  return (
    <Suspense fallback={<FindPageFallback />}>
      <FindPageContent />
    </Suspense>
  )
}
